import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';



class ESPWebView extends StatefulWidget {
  @override
  _ESPWebViewState createState() => _ESPWebViewState();
}

class _ESPWebViewState extends State<ESPWebView> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel(
        'ResponseChannel',
        onMessageReceived: (message) {
          // Navigate to SuccessScreen and pass the data
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SuccessScreen(response: message.message),
            ),
          );
        },
      )
      ..loadRequest(Uri.parse('http://192.168.1.6')); // Replace with your ESP IP
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('ESP WebView')),
      body: WebViewWidget(controller: _controller),
    );
  }
}

class SuccessScreen extends StatelessWidget {
  final String response;
  const SuccessScreen({required this.response});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Success')),
      body: Center(
        child: Text(
          'Received from ESP:\n$response',
          style: TextStyle(fontSize: 24),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
